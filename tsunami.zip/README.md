# tsunami
main parts of operating systems and simulation for other important parts in the operating systems
